<?php
session_start();
include "config.php";
requireAdmin();
$active_page = 'kegiatan';
$page_title  = 'Kegiatan Harian';

if (isset($_GET['hapus'])) {
    $id = (int)$_GET['hapus'];
    mysqli_query($conn, "DELETE FROM kegiatan WHERE id_kegiatan=$id");
    setFlash('success','Data berhasil dihapus.'); redirect('pkl-kegiatan.php');
}

if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['simpan'])) {
    $cols_val = [];
    $sets     = [];
    $id = (int)($_POST['id']??0);
    $Hari_tanggal = clean($_POST["Hari_tanggal"]??"");
    $Waktu_kegiatan = clean($_POST["Waktu_kegiatan"]??"");
    $Kegiatan_Pelaksanaan = clean($_POST["Kegiatan_Pelaksanaan"]??"");
    $id_siswa = (int)($_POST["id_siswa"]??0);

    if ($id) {
        mysqli_query($conn, "UPDATE `kegiatan` SET `Hari_tanggal`='$Hari_tanggal',`Waktu_kegiatan`='$Waktu_kegiatan',`Kegiatan_Pelaksanaan`='$Kegiatan_Pelaksanaan',`id_siswa`=$id_siswa WHERE `id_kegiatan`=$id");
        setFlash('success','Data berhasil diperbarui.');
    } else {
        mysqli_query($conn, "INSERT INTO `kegiatan` (`Hari_tanggal`,`Waktu_kegiatan`,`Kegiatan_Pelaksanaan`,`id_siswa`) VALUES ('$Hari_tanggal','$Waktu_kegiatan','$Kegiatan_Pelaksanaan',$id_siswa)");
        setFlash('success','Data baru berhasil ditambahkan.');
    }
    redirect('pkl-kegiatan.php');
}

$siswa_opt = mysqli_query($conn,'SELECT * FROM siswa ORDER BY Nama_siswa');

$rows = mysqli_query($conn, "SELECT kg.*,s.Nama_siswa FROM kegiatan kg LEFT JOIN siswa s ON kg.id_siswa=s.id_siswa ORDER BY kg.id_kegiatan DESC");
include '_header_admin.php';
?>
<div class="page-header">
  <h2><i class="fas fa-book-open"></i> Kegiatan Harian</h2>
  <button class="btn btn-primary btn-sm" onclick="document.getElementById('modal_kegiatan').classList.add('active')">
    <i class="fas fa-plus"></i> Tambah
  </button>
</div>
<div class="card">
  <div class="table-wrapper">
    <table>
      <thead><tr><th>#</th><th>Tanggal</th><th>Waktu</th><th>Kegiatan</th><th>Siswa</th><th>Aksi</th></tr></thead>
      <tbody>
      <?php $no=1; while($row=mysqli_fetch_assoc($rows)): ?>
      <tr>
        <td><?php echo $no++;?></td>
        <td><?php echo htmlspecialchars($row['Hari_tanggal']??'-');?></td><td><?php echo htmlspecialchars($row['Waktu_kegiatan']??'-');?></td><td><?php echo htmlspecialchars($row['Kegiatan_Pelaksanaan']??'-');?></td><td><?php echo htmlspecialchars($row['Nama_siswa']??'-');?></td>
        <td style="display:flex;gap:6px;">
          <a href="?hapus=<?php echo $row['id_kegiatan'];?>" class="btn btn-danger btn-sm"
             onclick="return confirm('Hapus data ini?')"><i class="fas fa-trash"></i></a>
        </td>
      </tr>
      <?php endwhile;?>
      </tbody>
    </table>
  </div>
</div>

<div class="modal-overlay" id="modal_kegiatan">
  <div class="modal">
    <div class="modal-header">
      <h3><i class="fas fa-book-open" style="margin-right:8px;color:#94a3b8;"></i> Tambah Kegiatan Harian</h3>
      <button class="modal-close" onclick="document.getElementById('modal_kegiatan').classList.remove('active')"><i class="fas fa-times"></i></button>
    </div>
    <form method="POST">
      <input type="hidden" name="id" value="0"/>
      
      <div class="form-group"><label>Tanggal</label>
        <input type="date" name="Hari_tanggal" class="form-control" />
      </div>
      <div class="form-group"><label>Waktu Kegiatan</label>
        <input type="text" name="Waktu_kegiatan" class="form-control" placeholder="08:00 - 17:00"/>
      </div>
      <div class="form-group"><label>Kegiatan Pelaksanaan</label>
        <input type="text" name="Kegiatan_Pelaksanaan" class="form-control" placeholder="Deskripsi kegiatan"/>
      </div>
      <div class="form-group"><label>Siswa</label>
        <select name="id_siswa" class="form-control">
          <?php while($rs=mysqli_fetch_assoc($siswa_opt)): ?>
          <option value="<?php echo $rs['id_siswa'];?>"><?php echo htmlspecialchars($rs['Nama_siswa']);?></option>
          <?php endwhile;?>
        </select>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-sm" onclick="document.getElementById('modal_kegiatan').classList.remove('active')">Batal</button>
        <button type="submit" name="simpan" class="btn btn-primary btn-sm"><i class="fas fa-save"></i> Simpan</button>
      </div>
    </form>
  </div>
</div>
<?php include '_footer_admin.php'; ?>
