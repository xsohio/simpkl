<?php
// Letakkan ob_start di paling atas untuk mencegah error "Headers already sent"
ob_start();
session_start();
include "config.php";

// 1. Ambil data dari POST/GET
if (isset($_GET['hapus'])) {
    $id = clean($_GET['hapus']);
    
    // Ambil username untuk keperluan log
    $res = mysqli_query($conn, "SELECT username FROM users WHERE id_users = '$id'");
    $data = mysqli_fetch_assoc($res);
    $nama = $data['username'] ?? 'Unknown';

    // Soft Delete (is_deleted = 1)
    if (mysqli_query($conn, "UPDATE users SET is_deleted = 1 WHERE id_users = '$id'")) {
        catatLog($conn, "Menghapus user: $nama");
        setFlash('success', 'User berhasil dihapus.');
    }
    redirect('admin-users.php');
}
// --- Di dalam file user_aksi.php bagian isset($_POST['simpan']) ---

if (isset($_POST['simpan'])) {
    $id       = clean($_POST['id']);
    $nis_nik  = clean($_POST['nis_nik']); // Tangkap input baru
    $username = clean($_POST['username']);
    $role     = clean($_POST['role']);
    $password = $_POST['password'];

    if ($id == "0") {
        // PROSES TAMBAH: Cek apakah NIS/NIK sudah terdaftar
        $cek = mysqli_query($conn, "SELECT nis_nik FROM users WHERE nis_nik = '$nis_nik' AND is_deleted = 0");
        
        if (mysqli_num_rows($cek) > 0) {
            // Jika ditemukan, batalkan simpan
            setFlash('error', 'Gagal! NIS/NIK sudah digunakan oleh user lain.');
            header("Location: admin-users.php");
            exit();
        }

        $query = "INSERT INTO users (nis_nik, username, password, role, is_deleted) 
                  VALUES ('$nis_nik', '$username', '$password', '$role', 0)";
    } else {
        // PROSES EDIT: Pastikan NIS tidak bentrok dengan user lain kecuali dirinya sendiri
        $cek = mysqli_query($conn, "SELECT nis_nik FROM users WHERE nis_nik = '$nis_nik' AND id_users != '$id' AND is_deleted = 0");
        
        if (mysqli_num_rows($cek) > 0) {
            setFlash('error', 'Gagal! NIS/NIK tersebut sudah milik user lain.');
            header("Location: admin-users.php");
            exit();
        }

        $query = "UPDATE users SET nis_nik='$nis_nik', username='$username', role='$role' ";
        if (!empty($password)) $query .= ", password='$password' ";
        $query .= " WHERE id_users='$id'";
    }

    if (mysqli_query($conn, $query)) {
        setFlash('success', 'Data user berhasil diperbarui.');
    }
    redirect('admin-users.php');
}

// Kalau nyasar
header("Location: admin-users.php");
exit(); 