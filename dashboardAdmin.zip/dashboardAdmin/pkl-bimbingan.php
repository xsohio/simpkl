<?php
session_start();
include "config.php";
requireAdmin();

// --- 1. PROSES HAPUS ---
if (isset($_GET['hapus'])) {
    $id = (int)$_GET['hapus'];
    $res = mysqli_query($conn, "SELECT materi_pembimbing FROM bimbingan WHERE id_bimbingan=$id");
    $materi = mysqli_fetch_assoc($res)['materi_pembimbing'] ?? 'Unknown';

    if (mysqli_query($conn, "DELETE FROM bimbingan WHERE id_bimbingan=$id")) {
        catatLog($conn, "Menghapus data bimbingan: $materi");
        setFlash('success','Data berhasil dihapus.'); 
    }
    redirect('pkl-bimbingan.php');
}

// --- 2. PROSES SIMPAN ---
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['simpan'])) {
    $id = (int)($_POST['id']??0);
    $materi = clean($_POST["materi_pembimbing"]);
    $catatan = clean($_POST["catatan_pembimbing"]);
    $tgl = clean($_POST["hari_tanggal_bimbingan"]);
    $id_pembimbing = (int)$_POST["id_pembimbing"];

    if ($id == 0) {
        $sql = "INSERT INTO `bimbingan` (`materi_pembimbing`,`catatan_pembimbing`,`hari_tanggal_bimbingan`,`id_pembimbing`) 
                VALUES ('$materi','$catatan','$tgl',$id_pembimbing)";
        $msg = "Menambah bimbingan baru: $materi";
    } else {
        $sql = "UPDATE `bimbingan` SET `materi_pembimbing`='$materi', `catatan_pembimbing`='$catatan', 
                `hari_tanggal_bimbingan`='$tgl', `id_pembimbing`=$id_pembimbing WHERE `id_bimbingan`=$id";
        $msg = "Mengubah data bimbingan: $materi";
    }

    if (mysqli_query($conn, $sql)) {
        catatLog($conn, $msg);
        setFlash('success', 'Data berhasil disimpan.');
    }
    redirect('pkl-bimbingan.php');
}
$rows = mysqli_query($conn, "SELECT bimbingan.*, pembimbing_pkl.nama 
                             FROM bimbingan 
                             LEFT JOIN pembimbing_pkl ON bimbingan.id_pembimbing = pembimbing_pkl.id_pembimbing 
                             ORDER BY id_bimbingan DESC");

// Ambil data untuk Dropdown di Modal (Ini yang sering bikin tombol tambah hilang jika error)
$query = mysqli_query($conn, "SELECT id_pembimbing, nama FROM pembimbing_pkl ORDER BY nama");

$active_page = 'bimbingan';
$page_title  = 'Data Bimbingan';
include '_header_admin.php';
?>
<div class="page-header">
  <h2><i class="fas fa-comments"></i> Data Bimbingan</h2>
  <button class="btn btn-primary btn-sm" onclick="document.getElementById('modal_bimbingan').classList.add('active')">
    <i class="fas fa-plus"></i> Tambah
  </button>
</div>
<div class="card">
  <div class="table-wrapper">
    <table>
      <thead><tr><th>#</th><th>Materi</th><th>Catatan</th><th>Tanggal</th><th>Pembimbing</th><th>Aksi</th></tr></thead>
      <tbody>
      <?php $no=1; while($row=mysqli_fetch_assoc($rows)): ?>
      <tr>
        <td><?php echo $no++;?></td>
        <td><?php echo htmlspecialchars($row['materi_pembimbing']??'-');?></td><td><?php echo htmlspecialchars($row['catatan_pembimbing']??'-');?></td><td><?php echo htmlspecialchars($row['hari_tanggal_bimbingan']??'-');?></td><td><?php echo htmlspecialchars($row['nama_pmb']??'-');?></td>
        <td style="display:flex;gap:6px;">
          <a href="?hapus=<?php echo $row['id_bimbingan'];?>" class="btn btn-danger btn-sm"
             onclick="return confirm('Hapus data ini?')"><i class="fas fa-trash"></i></a>
        </td>
      </tr>
      <?php endwhile;?>
      </tbody>
    </table>
  </div>
</div>

<div class="modal-overlay" id="modal_bimbingan">
  <div class="modal">
    <div class="modal-header">
      <h3><i class="fas fa-comments" style="margin-right:8px;color:#94a3b8;"></i> Tambah Data Bimbingan</h3>
      <button class="modal-close" onclick="document.getElementById('modal_bimbingan').classList.remove('active')"><i class="fas fa-times"></i></button>
    </div>
    <form method="POST">
      <input type="hidden" name="id" value="0"/>
      
      <div class="form-group"><label>Materi Bimbingan</label>
        <input type="text" name="materi_pembimbing" class="form-control" placeholder="Topik bimbingan"/>
      </div>
      <div class="form-group"><label>Catatan</label>
        <input type="text" name="catatan_pembimbing" class="form-control" placeholder="Catatan pembimbing"/>
      </div>
      <div class="form-group"><label>Tanggal</label>
        <input type="date" name="hari_tanggal_bimbingan" class="form-control" />
      </div>
      <div class="form-group"><label>Pembimbing</label>
        <select name="id_pembimbing" class="form-control">
          <?php while($rpmb=mysqli_fetch_assoc($query)): ?>
          <option value="<?php echo $rpmb['id_pembimbing'];?>"><?php echo htmlspecialchars($rpmb['nama']);?></option>
          <?php endwhile;?>
        </select>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-sm" onclick="document.getElementById('modal_bimbingan').classList.remove('active')">Batal</button>
        <button type="submit" name="simpan" class="btn btn-primary btn-sm"><i class="fas fa-save"></i> Simpan</button>
      </div>
    </form>
  </div>
</div>
<?php include '_footer_admin.php'; ?>
