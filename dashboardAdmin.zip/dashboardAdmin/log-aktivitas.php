<?php
session_start();
include "config.php";
requireAdmin();

// --- LOGIKA HAPUS LOG ---
if (isset($_GET['hapus'])) {
    $id_log = (int)$_GET['hapus'];
    
    // Proses hapus dari database
    $query_hapus = "DELETE FROM log_aktivitas WHERE id_log = $id_log";
    
    if (mysqli_query($conn, $query_hapus)) {
        setFlash('success', 'Catatan log berhasil dihapus.');
    } else {
        setFlash('error', 'Gagal menghapus log.');
    }
    redirect('log-aktivitas.php');
}

// --- LOGIKA BERSIHKAN SEMUA LOG (OPSIONAL) ---
if (isset($_GET['bersihkan_semua'])) {
    if (mysqli_query($conn, "TRUNCATE TABLE log_aktivitas")) {
        setFlash('success', 'Semua log telah dibersihkan.');
    }
    redirect('log-aktivitas.php');
}

$active_page = 'log';
$page_title  = 'Log Aktivitas';
include '_header_admin.php';

// Ambil data log
$query = "SELECT log_aktivitas.*, users.username 
          FROM log_aktivitas 
          LEFT JOIN users ON log_aktivitas.id_users = users.id_users 
          ORDER BY log_aktivitas.waktu DESC";
$result = mysqli_query($conn, $query);
?>

<div class="page-header">
    <h2><i class="fas fa-history"></i> Log Aktivitas Sistem</h2>
    <a href="log-aktivitas.php?bersihkan_semua=1" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus SEMUA log?')">
        <i class="fas fa-trash-alt"></i> Bersihkan Semua Log
    </a>
</div>

<?php getFlash(); ?>

<div class="card">
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Waktu</th>
                    <!-- <th>User</th> -->
                    <th>Aktivitas</th>
                    <th style="text-align:center;">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $no = 1;
                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) { ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= date('d M Y, H:i', strtotime($row['waktu'])); ?></td>
                            <!-- <td> -->
                                <!-- <span class="badge badge-info"> -->
                                    <!-- <i class="fas fa-user"></i> <?= htmlspecialchars($row['username'] ?? 'System/Deleted'); ?> -->
                                <!-- </span> -->
                            <!-- </td> -->
                            <td><?= htmlspecialchars($row['aktivitas']); ?></td>
                            <td style="text-align:center;">
                                <a href="log-aktivitas.php?hapus=<?= $row['id_log']; ?>" 
                                   class="btn-del" 
                                   onclick="return confirm('Hapus catatan log ini?')"
                                   style="color:#ef4444; font-size: 0.8rem; text-decoration: none;">
                                    <i class="fas fa-trash"></i> Hapus
                                </a>
                            </td>
                        </tr>
                    <?php } 
                } else { ?>
                    <tr>
                        <td colspan="5" style="text-align:center; padding: 20px;">Belum ada aktivitas yang tercatat.</td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<?php include '_footer_admin.php'; ?>