<?php
session_start();
include "config.php";
requireAdmin();
$active_page = 'kopetensi';
$page_title  = 'Data Kompetensi';

if (isset($_GET['hapus'])) {
    $id = (int)$_GET['hapus'];
    mysqli_query($conn, "DELETE FROM kopetensi WHERE id_kopetensi=$id");
    setFlash('success','Data berhasil dihapus.'); redirect('pkl-kopetensi.php');
}

if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['simpan'])) {
    $cols_val = [];
    $sets     = [];
    $id = (int)($_POST['id']??0);
    $Kopetensi_dasar = clean($_POST["Kopetensi_dasar"]??"");
    $Keterlaksanaan = clean($_POST["Keterlaksanaan"]??"");
    $id_siswa = (int)($_POST["id_siswa"]??0);

    if ($id) {
        mysqli_query($conn, "UPDATE `kopetensi` SET `Kopetensi_dasar`='$Kopetensi_dasar',`Keterlaksanaan`='$Keterlaksanaan',`id_siswa`=$id_siswa WHERE `id_kopetensi`=$id");
        setFlash('success','Data berhasil diperbarui.');
    } else {
        mysqli_query($conn, "INSERT INTO `kopetensi` (`Kopetensi_dasar`,`Keterlaksanaan`,`id_siswa`) VALUES ('$Kopetensi_dasar','$Keterlaksanaan',$id_siswa)");
        setFlash('success','Data baru berhasil ditambahkan.');
    }
    redirect('pkl-kopetensi.php');
}

$siswa_opt = mysqli_query($conn,'SELECT * FROM siswa ORDER BY Nama_siswa');

$rows = mysqli_query($conn, "SELECT kp.*,s.Nama_siswa FROM kopetensi kp LEFT JOIN siswa s ON kp.id_siswa=s.id_siswa ORDER BY kp.id_kopetensi DESC");
include '_header_admin.php';
?>
<div class="page-header">
  <h2><i class="fas fa-tasks"></i> Data Kompetensi</h2>
  <button class="btn btn-primary btn-sm" onclick="document.getElementById('modal_kopetensi').classList.add('active')">
    <i class="fas fa-plus"></i> Tambah
  </button>
</div>
<div class="card">
  <div class="table-wrapper">
    <table>
      <thead><tr><th>#</th><th>Kompetensi Dasar</th><th>Keterlaksanaan</th><th>Siswa</th><th>Aksi</th></tr></thead>
      <tbody>
      <?php $no=1; while($row=mysqli_fetch_assoc($rows)): ?>
      <tr>
        <td><?php echo $no++;?></td>
        <td><?php echo htmlspecialchars($row['Kopetensi_dasar']??'-');?></td><td><?php echo htmlspecialchars($row['Keterlaksanaan']??'-');?></td><td><?php echo htmlspecialchars($row['Nama_siswa']??'-');?></td>
        <td style="display:flex;gap:6px;">
          <a href="?hapus=<?php echo $row['id_kopetensi'];?>" class="btn btn-danger btn-sm"
             onclick="return confirm('Hapus data ini?')"><i class="fas fa-trash"></i></a>
        </td>
      </tr>
      <?php endwhile;?>
      </tbody>
    </table>
  </div>
</div>

<div class="modal-overlay" id="modal_kopetensi">
  <div class="modal">
    <div class="modal-header">
      <h3><i class="fas fa-tasks" style="margin-right:8px;color:#94a3b8;"></i> Tambah Data Kompetensi</h3>
      <button class="modal-close" onclick="document.getElementById('modal_kopetensi').classList.remove('active')"><i class="fas fa-times"></i></button>
    </div>
    <form method="POST">
      <input type="hidden" name="id" value="0"/>
      
      <div class="form-group"><label>Kompetensi Dasar</label>
        <input type="text" name="Kopetensi_dasar" class="form-control" placeholder="Nama kompetensi"/>
      </div>
      <div class="form-group"><label>Keterlaksanaan</label>
        <input type="text" name="Keterlaksanaan" class="form-control" placeholder="Terlaksana / Belum"/>
      </div>
      <div class="form-group"><label>Siswa</label>
        <select name="id_siswa" class="form-control">
          <?php while($rs=mysqli_fetch_assoc($siswa_opt)): ?>
          <option value="<?php echo $rs['id_siswa'];?>"><?php echo htmlspecialchars($rs['Nama_siswa']);?></option>
          <?php endwhile;?>
        </select>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-sm" onclick="document.getElementById('modal_kopetensi').classList.remove('active')">Batal</button>
        <button type="submit" name="simpan" class="btn btn-primary btn-sm"><i class="fas fa-save"></i> Simpan</button>
      </div>
    </form>
  </div>
</div>
<?php include '_footer_admin.php'; ?>
